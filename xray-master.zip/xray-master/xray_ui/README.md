# Xray UI

This folder houses Xray's user interface, which is implemented in JavaScript and designed to run in a web environment. It is depended upon by [`xray_electron`](../xray_electron), which presents Xray as a desktop application, and [`xray_browser`](../xray_browser), which presents Xray in the browser.

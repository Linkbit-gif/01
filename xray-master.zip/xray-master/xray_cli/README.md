# Xray CLI

This crate is an executable that provides a command-line interface for Xray. It can spawn `xray_server` in headless mode or launch the `xray_electron` application. It sends commands to `xray_server` over a domain socket.

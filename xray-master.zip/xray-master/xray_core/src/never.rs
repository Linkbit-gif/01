#[derive(Debug, Serialize, Deserialize)]
pub enum Never {}
